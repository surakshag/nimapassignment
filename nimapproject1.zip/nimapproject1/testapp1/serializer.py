from rest_framework import serializers
from testapp1.models import client

class clientserializer(serializers.Serializer):
    Client_name=serializers.CharField(max_length=100)
    Created_at=serializers.DateTimeField()
    Created_by=serializers.CharField(max_length=100)
