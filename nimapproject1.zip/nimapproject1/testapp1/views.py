from django.shortcuts import render
from testapp1.models import client
from testapp1.serializer import clientserializer
from rest_framework.renderers import JSONRenderer
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from testapp1.forms import RegistrationForm


# Create your views here.
def client_info(request):
    name=client.objects.all()
    print(name)
    serializers=clientserializer(name,many=True)
    print(serializers)
    json_data=JSONRenderer().render(serializers.data)
    print(json_data)
    return HttpResponse(json_data,content_type='application/json')

#class
