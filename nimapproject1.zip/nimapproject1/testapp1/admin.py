from django.contrib import admin
from testapp1.models import client
# Register your models here.

class clientadmin(admin.ModelAdmin):
    list_display=['id','Client_name','Created_at','Created_by']
admin.site.register(client,clientadmin)
