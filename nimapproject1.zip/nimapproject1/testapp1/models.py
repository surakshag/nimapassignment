from django.db import models

# Create your models here.
class client(models.Model):
    Client_name=models.CharField(max_length=100)
    Created_at=models.DateTimeField()
    Created_by=models.CharField(max_length=100)
